
import React, { useState } from 'react';
import { StatusBar } from 'react-native';

import LoginScreen from './screens/LoginScreen';
import HomeScreen from './screens/HomeScreen';
import ProfileScreen from './screens/ProfileScreen';

export default function App() {
  const [halaman, setHalaman] = useState('login');
  const [email, setEmail] = useState('');

  const nama = 'Ardianti Malika Putri';
  const nim = '4112755201250194';

  return (
    <>
      <StatusBar
        backgroundColor="#F06292"
        barStyle="light-content"
      />

      {halaman === 'login' && (
        <LoginScreen
          onLogin={(emailInput) => {
            setEmail(emailInput);
            setHalaman('home');
          }}
        />
      )}

      {halaman === 'home' && (
        <HomeScreen
          nama={nama}
          nim={nim}
          email={email}
          onProfile={() => setHalaman('profile')}
          onLogout={() => setHalaman('login')}
        />
      )}

      {halaman === 'profile' && (
        <ProfileScreen
          nama={nama}
          nim={nim}
          email={email}
          onBack={() => setHalaman('home')}
          onLogout={() => setHalaman('login')}
        />
      )}
    </>
  );
}
