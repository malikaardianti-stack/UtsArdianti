
import React from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Alert,
} from 'react-native';

export default function ProfileScreen({
  nama,
  nim,
  email,
  onBack,
  onLogout,
}) {
  const detail = [
    { label: 'Nama Lengkap', value: nama },
    { label: 'NIM', value: nim },
    { label: 'Program Studi', value: 'S1 Informatika' },
    { label: 'Email', value: email },
    { label: 'Status', value: 'Mahasiswa Aktif' },
  ];

  const handleLogout = () => {
    Alert.alert('Logout', 'Yakin ingin keluar?', [
      { text: 'Batal', style: 'cancel' },
      { text: 'Ya, Logout', onPress: onLogout },
    ]);
  };

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.content}
    >
      <TouchableOpacity
        style={styles.backButton}
        onPress={onBack}
      >
        <Text style={styles.backText}>← Kembali ke Home</Text>
      </TouchableOpacity>

      <Text style={styles.pageTitle}>My Profile</Text>
      <Text style={styles.pageSubtitle}>
        Informasi profil mahasiswa
      </Text>

      <View style={styles.profileCard}>
        <Image
          source={require('../assets/foto.jpeg')}
          style={styles.avatar}
          resizeMode="cover"
        />

        <Text style={styles.name}>{nama}</Text>
        <Text style={styles.nim}>NIM: {nim}</Text>

        <View style={styles.badge}>
          <Text style={styles.badgeText}>
            ✦ STUDENT PROFILE
          </Text>
        </View>
      </View>

      <Text style={styles.sectionTitle}>
        Personal Information
      </Text>

      <View style={styles.detailsCard}>
        {detail.map((item, index) => (
          <View key={item.label}>
            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>
                {item.label}
              </Text>

              <Text style={styles.detailValue}>
                {item.value || '-'}
              </Text>
            </View>

            {index !== detail.length - 1 && (
              <View style={styles.separator} />
            )}
          </View>
        ))}
      </View>

      <View style={styles.note}>
        <Text style={styles.noteTitle}>
          🌸 About Me
        </Text>

        <Text style={styles.noteText}>
          Halo! Saya {nama}, mahasiswa S1 Informatika.
          Saya sedang belajar pemrograman dan pengembangan
          aplikasi mobile menggunakan React Native.
        </Text>
      </View>

      <TouchableOpacity
        style={styles.logoutButton}
        onPress={handleLogout}
      >
        <Text style={styles.logoutText}>
          ↪ LOGOUT
        </Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF5F8',
  },
  content: {
    padding: 22,
    paddingBottom: 35,
  },
  backButton: {
    alignSelf: 'flex-start',
    paddingVertical: 12,
    paddingHorizontal: 15,
    borderRadius: 12,
    backgroundColor: '#FFE5EF',
    marginTop: 12,
    marginBottom: 20,
  },
  backText: {
    color: '#D94F82',
    fontWeight: 'bold',
    fontSize: 12,
  },
  pageTitle: {
    fontSize: 28,
    fontWeight: '900',
    color: '#583344',
  },
  pageSubtitle: {
    color: '#A87D8D',
    fontSize: 12,
    marginTop: 5,
    marginBottom: 22,
  },
  profileCard: {
    backgroundColor: '#F06292',
    borderRadius: 23,
    padding: 25,
    alignItems: 'center',
    marginBottom: 25,
    elevation: 4,
  },
  avatar: {
    width: 110,
    height: 110,
    borderRadius: 55,
    borderWidth: 4,
    borderColor: '#FFD8E5',
    marginBottom: 15,
    backgroundColor: '#FFFFFF',
  },
  name: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  nim: {
    color: '#FFE5EF',
    fontSize: 12,
    marginTop: 7,
  },
  badge: {
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    paddingHorizontal: 15,
    paddingVertical: 8,
    marginTop: 15,
  },
  badgeText: {
    color: '#D94F82',
    fontSize: 10,
    fontWeight: 'bold',
    letterSpacing: 1,
  },
  sectionTitle: {
    color: '#583344',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 13,
  },
  detailsCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 19,
    padding: 18,
    borderWidth: 1,
    borderColor: '#FFD8E5',
  },
  detailRow: {
    paddingVertical: 13,
  },
  detailLabel: {
    color: '#A87D8D',
    fontSize: 11,
    marginBottom: 7,
  },
  detailValue: {
    color: '#583344',
    fontSize: 13,
    fontWeight: 'bold',
  },
  separator: {
    height: 1,
    backgroundColor: '#FFE5EF',
  },
  note: {
    backgroundColor: '#FFE8F0',
    padding: 17,
    borderRadius: 17,
    marginTop: 20,
    marginBottom: 20,
  },
  noteTitle: {
    color: '#D94F82',
    fontSize: 14,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  noteText: {
    color: '#80576A',
    fontSize: 12,
    lineHeight: 20,
  },
  logoutButton: {
    height: 49,
    borderRadius: 14,
    borderWidth: 1.5,
    borderColor: '#F06292',
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoutText: {
    color: '#D94F82',
    fontWeight: 'bold',
    letterSpacing: 2,
  },
});
