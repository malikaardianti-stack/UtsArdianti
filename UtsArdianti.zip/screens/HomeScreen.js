
import React from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

export default function HomeScreen({
  nama,
  nim,
  onProfile,
  onLogout,
}) {
  const menus = [
    {
      title: 'My Profile',
      subtitle: 'Data diri mahasiswa',
      icon: 'person-outline',
      action: onProfile,
    },
    {
      title: 'My Study',
      subtitle: 'Informasi perkuliahan',
      icon: 'book-outline',
      action: () =>
        Alert.alert('My Study', 'Menu informasi perkuliahan'),
    },
    {
      title: 'Assignments',
      subtitle: 'Daftar tugas kuliah',
      icon: 'document-text-outline',
      action: () =>
        Alert.alert('Assignments', 'Menu daftar tugas kuliah'),
    },
    {
      title: 'Settings',
      subtitle: 'Pengaturan aplikasi',
      icon: 'settings-outline',
      action: () =>
        Alert.alert('Settings', 'Menu pengaturan aplikasi'),
    },
  ];

  const handleLogout = () => {
    Alert.alert('Logout', 'Yakin ingin keluar?', [
      { text: 'Batal', style: 'cancel' },
      { text: 'Ya, Logout', onPress: onLogout },
    ]);
  };

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.content}
      showsVerticalScrollIndicator={false}
    >

      <View style={styles.header}>
        <View>
          <Text style={styles.brand}>MY APP UTS MOBILE 1</Text>
          <Text style={styles.pageTitle}>Home Page</Text>
        </View>

        <Ionicons
          name="heart"
          size={32}
          color="#F06292"
        />
      </View>

      
      <TouchableOpacity
        style={styles.profileCard}
        onPress={onProfile}
        activeOpacity={0.85}
      >
        <Image
          source={require('../assets/foto.jpeg')}
          style={styles.profileImage}
          resizeMode="cover"
        />

        <View style={styles.profileInfo}>
          <Text style={styles.welcome}>WELCOME,</Text>

          <Text style={styles.name}>{nama}</Text>

          <Text style={styles.nim}>NIM: {nim}</Text>
        </View>

        <Ionicons
          name="heart-outline"
          size={28}
          color="#E85D8D"
          style={styles.heartIcon}
        />
      </TouchableOpacity>

      
      <View style={styles.menuGrid}>
        {menus.map((menu, index) => (
          <TouchableOpacity
            key={menu.title}
            style={[
              styles.menuCard,
              index === 0 || index === 3
                ? styles.pinkCard
                : styles.whiteCard,
            ]}
            onPress={menu.action}
            activeOpacity={0.75}
          >
            <View style={styles.iconCircle}>
              <Ionicons
                name={menu.icon}
                size={38}
                color="#B92D60"
              />
            </View>

            <Text style={styles.menuTitle}>
              {menu.title}
            </Text>

            <Text style={styles.menuSubtitle}>
              {menu.subtitle}
            </Text>

            <Ionicons
              name="chevron-forward"
              size={25}
              color="#E85D8D"
              style={styles.chevron}
            />
          </TouchableOpacity>
        ))}
      </View>

      <TouchableOpacity
        style={styles.logoutButton}
        onPress={handleLogout}
        activeOpacity={0.8}
      >
        <Ionicons
          name="log-out-outline"
          size={30}
          color="#FFFFFF"
        />

        <Text style={styles.logoutText}>LOGOUT</Text>
      </TouchableOpacity>

      <Text style={styles.footer}>
        © 2026 My Pink App
      </Text>

      <Text style={styles.footerName}>
        {nama}
      </Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF7FA',
  },

  content: {
    paddingHorizontal: 22,
    paddingTop: 45,
    paddingBottom: 30,
  },

  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 30,
  },

  brand: {
    color: '#E85D8D',
    fontSize: 13,
    fontWeight: 'bold',
    letterSpacing: 3,
  },

  pageTitle: {
    color: '#783052',
    fontSize: 34,
    fontWeight: '900',
    marginTop: 8,
  },

  profileCard: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1.5,
    borderColor: '#F8A9C5',
    borderRadius: 25,
    padding: 18,
    minHeight: 180,
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 28,
    elevation: 3,
    shadowColor: '#D96B91',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.12,
    shadowRadius: 8,
  },

  profileImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
    borderWidth: 3,
    borderColor: '#F8A9C5',
  },

  profileInfo: {
    flex: 1,
    marginLeft: 14,
  },

  welcome: {
    color: '#E85D8D',
    fontWeight: 'bold',
    fontSize: 13,
    letterSpacing: 1,
    marginBottom: 7,
  },

  name: {
    color: '#783052',
    fontWeight: 'bold',
    fontSize: 17,
    lineHeight: 23,
  },

  nim: {
    color: '#B57999',
    fontSize: 12,
    marginTop: 9,
  },

  heartIcon: {
    position: 'absolute',
    right: 12,
    top: 12,
  },

  menuGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },

  menuCard: {
    width: '48%',
    minHeight: 185,
    borderRadius: 22,
    borderWidth: 1.5,
    borderColor: '#FFD6E5',
    padding: 15,
    marginBottom: 16,
    justifyContent: 'flex-start',
    shadowColor: '#D96B91',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 5,
    elevation: 2,
  },

  pinkCard: {
    backgroundColor: '#FFF0F5',
  },

  whiteCard: {
    backgroundColor: '#FFFFFF',
  },

  iconCircle: {
    width: 65,
    height: 65,
    borderRadius: 33,
    backgroundColor: '#FFD8E7',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 14,
  },

  menuTitle: {
    color: '#783052',
    fontWeight: 'bold',
    fontSize: 15,
    marginBottom: 6,
  },

  menuSubtitle: {
    color: '#AB7895',
    fontSize: 11,
    lineHeight: 16,
    paddingRight: 4,
  },

  chevron: {
    position: 'absolute',
    right: 8,
    bottom: 22,
  },

  logoutButton: {
    backgroundColor: '#E95488',
    alignSelf: 'center',
    width: 190,
    height: 58,
    borderRadius: 17,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
    marginTop: 10,
    marginBottom: 25,
    elevation: 4,
    shadowColor: '#D94F82',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
  },

  logoutText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: 'bold',
    letterSpacing: 2,
  },

  footer: {
    color: '#B57999',
    fontSize: 12,
    textAlign: 'center',
  },

  footerName: {
    color: '#B57999',
    fontSize: 11,
    textAlign: 'center',
    marginTop: 5,
  },
});
