
import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Alert,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';

export default function LoginScreen({ onLogin }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [lihatPassword, setLihatPassword] = useState(false);

  const handleLogin = () => {
    if (!email.trim() || !password.trim()) {
      Alert.alert('Login Gagal', 'Email dan password wajib diisi!');
      return;
    }

    onLogin(email.trim());
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView
        contentContainerStyle={styles.scroll}
        keyboardShouldPersistTaps="handled"
      >
        <View style={styles.card}>
          <View style={styles.logo}>
            <Text style={styles.logoText}>A</Text>
          </View>

          <Text style={styles.title}>MY APP UTS MOBILE 1</Text>
          <Text style={styles.subtitle}>
            Welcome to your personal space ♡
          </Text>

          

          <Text style={styles.heading}>Sign In</Text>
          <Text style={styles.description}>
            Silakan login untuk melanjutkan
          </Text>

          <Text style={styles.label}>Email Address</Text>
          <TextInput
            style={styles.input}
            placeholder="Masukkan email"
            placeholderTextColor="#B99AA7"
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            autoCapitalize="none"
            autoCorrect={false}
          />

          <Text style={styles.label}>Password</Text>
          <View style={styles.passwordBox}>
            <TextInput
              style={styles.passwordInput}
              placeholder="Masukkan password"
              placeholderTextColor="#B99AA7"
              value={password}
              onChangeText={setPassword}
              secureTextEntry={!lihatPassword}
            />

            <TouchableOpacity
              onPress={() => setLihatPassword(!lihatPassword)}
            >
              <Text style={styles.show}>
                {lihatPassword ? 'Hide' : 'Show'}
              </Text>
            </TouchableOpacity>
          </View>

          <TouchableOpacity
            style={styles.button}
            onPress={handleLogin}
          >
            <Text style={styles.buttonText}>LOGIN →</Text>
          </TouchableOpacity>

          <Text style={styles.footer}>
            Made with ♡ by Ardianti
          </Text>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF5F8',
  },
  scroll: {
    flexGrow: 1,
    justifyContent: 'center',
    padding: 22,
  },
  card: {
    backgroundColor: '#FFFFFF',
    padding: 24,
    borderRadius: 25,
    borderWidth: 1,
    borderColor: '#FFD8E5',
    elevation: 4,
  },
  logo: {
    alignSelf: 'center',
    width: 70,
    height: 70,
    borderRadius: 35,
    backgroundColor: '#F06292',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 15,
  },
  logoText: {
    color: '#FFFFFF',
    fontSize: 34,
    fontWeight: 'bold',
  },
  title: {
    textAlign: 'center',
    color: '#D94F82',
    fontSize: 24,
    fontWeight: '900',
    letterSpacing: 2,
  },
  subtitle: {
    textAlign: 'center',
    color: '#A87D8D',
    fontSize: 12,
    marginTop: 7,
    marginBottom: 20,
  },
  studentBox: {
    backgroundColor: '#FFF0F5',
    borderRadius: 15,
    padding: 13,
    alignItems: 'center',
    marginBottom: 22,
  },
  studentName: {
    color: '#583344',
    fontWeight: 'bold',
    fontSize: 14,
    textAlign: 'center',
  },
  nim: {
    color: '#A87D8D',
    fontSize: 11,
    marginTop: 5,
  },
  heading: {
    fontSize: 23,
    fontWeight: 'bold',
    color: '#583344',
  },
  description: {
    color: '#A87D8D',
    fontSize: 12,
    marginTop: 5,
    marginBottom: 20,
  },
  label: {
    color: '#583344',
    fontWeight: '600',
    fontSize: 12,
    marginBottom: 8,
  },
  input: {
    height: 50,
    borderWidth: 1,
    borderColor: '#F4CDDA',
    borderRadius: 13,
    paddingHorizontal: 14,
    color: '#583344',
    marginBottom: 17,
    backgroundColor: '#FFFAFC',
  },
  passwordBox: {
    flexDirection: 'row',
    alignItems: 'center',
    height: 50,
    borderWidth: 1,
    borderColor: '#F4CDDA',
    borderRadius: 13,
    paddingHorizontal: 14,
    marginBottom: 18,
    backgroundColor: '#FFFAFC',
  },
  passwordInput: {
    flex: 1,
    color: '#583344',
  },
  show: {
    color: '#D94F82',
    fontWeight: 'bold',
    fontSize: 12,
  },
  button: {
    height: 50,
    backgroundColor: '#F06292',
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
  },
  buttonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    letterSpacing: 2,
  },
  footer: {
    color: '#B99AA7',
    fontSize: 10,
    textAlign: 'center',
    marginTop: 22,
  },
});
